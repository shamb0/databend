cargo build --release --target wasm32-wasi

tar -cvzf test10-udf-wasm-gcd.tar.gz test10-udf-wasm-gcd