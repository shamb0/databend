use arrow_udf::function;

#[function("wasm_gcd(int, int)->int")]
fn wasm_gcd(mut a: i32, mut b: i32) -> i32 {
    while b != 0 {
        (a, b) = (b, a % b);
    }
    a
}